/*******************************************************************************

    Copyright (C) 2016 ZenMate
    Copyright (C) 2014-2016 Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

*/

/* global punycode, vAPI, uDom */

/******************************************************************************/

/*

    NOTE:
    The popup code is currently quite unsophisticated ES5 code.
    This will change soon when we refactor the file to be based on proper UI components.

*/

/******************************************************************************/


(function() {

'use strict';

/******************************************************************************/

var groupColors = {
    default: "#017DBA",
    content: "#008ACE",
    privacy: "#FF8900",
    ads: "#FFB800",
    security: "#FF5722",
}

var availableBlockGroups = [
    "privacy", "ads", "security"
]

var popupData = {};

// For cachePopupData
var scopeToSrcHostnameMap = {
    '/': '*',
    '.': ''
};
var hostnameToSortableTokenMap = {};
var cachedPopupHash = '';


/******************************************************************************/

// https://github.com/gorhill/httpswitchboard/issues/345
var messager = vAPI.messaging.channel('popup.js');

var zabMessager = vAPI.messaging.channel('zab');

/******************************************************************************/

var cachePopupData = function(data) {
    popupData = {};
    scopeToSrcHostnameMap['.'] = '';
    hostnameToSortableTokenMap = {};

    if ( typeof data !== 'object' ) {
        return popupData;
    }
    popupData = data;
    scopeToSrcHostnameMap['.'] = popupData.pageHostname || '';
    var hostnameDict = popupData.hostnameDict;
    if ( typeof hostnameDict !== 'object' ) {
        return popupData;
    }
    var domain, prefix;
    for ( var hostname in hostnameDict ) {
        if ( hostnameDict.hasOwnProperty(hostname) === false ) {
            continue;
        }
        domain = hostnameDict[hostname].domain;
        prefix = hostname.slice(0, 0 - domain.length);
        // Prefix with space char for 1st-party hostnames: this ensure these
        // will come first in list.
        if ( domain === popupData.pageDomain ) {
            domain = '\u0020';
        }
        hostnameToSortableTokenMap[hostname] = domain + prefix.split('.').reverse().join('.');
    }
    return popupData;
};

/******************************************************************************/

var hashFromPopupData = function(reset) {
    // It makes no sense to offer to refresh the behind-the-scene scope
    if ( popupData.pageHostname === 'behind-the-scene' ) {
        uDom('body').toggleClass('dirty', false);
        return;
    }

    var hasher = [];
    var rules = popupData.firewallRules;
    var rule;
    for ( var key in rules ) {
        if ( rules.hasOwnProperty(key) === false ) {
            continue;
        }
        rule = rules[key];
        if ( rule !== '' ) {
            hasher.push(rule);
        }
    }
    hasher.sort();
    hasher.push($("#mainswitch").prop("checked"));
    // TODO: Add more stuff once we have a menu in place
    // hasher.push(uDom('body').hasClass('off'));
    // hasher.push(uDom.nodeFromId('no-large-media').classList.contains('on'));
    // hasher.push(uDom.nodeFromId('no-cosmetic-filtering').classList.contains('on'));
    // hasher.push(uDom.nodeFromId('no-remote-fonts').classList.contains('on'));

    var hash = hasher.join('');
    if ( reset ) {
        cachedPopupHash = hash;
    }

    uDom('body').toggleClass('dirty', hash !== cachedPopupHash);
};

/******************************************************************************/

var formatNumber = function(count) {
    return typeof count === 'number' ? count.toLocaleString() : '';
};

/******************************************************************************/


var renderChart = function(chartData) {
    log.debug("zab > renderChart", chartData)

    d3.select("svg").remove(); // Clean up

    var width = 300,
        height = 300,
        radius = Math.min(width, height) / 2 - 10; // Make room for shadows

    var x = d3.scale.linear()
        .range([0, 2 * Math.PI]);

    var y = d3.scale.sqrt()
        .range([0, radius]);

    var color = d3.scale.category10();

    var svg = d3.select("#chart").append("svg")
        .attr("width", width)
        .attr("height", height)
        .append("g")
        .attr("id", "container")
        .attr("transform", "translate(" + width / 2 + "," + (height / 2 ) + ") rotate(-10 0 0)")
        .style("filter", "url(#drop-shadow)")

    var partition = d3.layout.partition()
        .sort(null)
        .value(function (d) { return d.size; });


    var arc = d3.svg.arc()
        .startAngle(function (d) {
            return Math.max(0, Math.min(2 * Math.PI, x(d.x)));
        })
        .endAngle(function (d) {
            return Math.max(0, Math.min(2 * Math.PI, x(d.x + d.dx)));
        })
        .innerRadius(function (d) {
            return Math.max(0, y(d.y)) ;
        })
        .outerRadius(function (d) {
            return Math.max(0, y(d.y + d.dy)); // ???
        })


    var root = chartData

    var g = svg.selectAll("g")
        .data(partition.nodes(root))
        .enter().append("g");

    var path = g.append("path")
        .attr("display", function(d) { return d.depth ? null : "none"; }) // hide inner ring
        .style("stroke", "#00A6DC")
        .attr('stroke-width', '1')
        .attr("stroke-opacity", "0.3")
        .attr("d", arc)
        .style("fill", function (d) {
            if (d.group && d.group === "content") { return "url(#gradient)" }
            var color = groupColors[d.group] || groupColors.default
            if (d.depth >= 2) { color = d3.rgb(color).darker(0.12) }
            return color
        })
        .attr("data-action", function (d) {
            return d.action;
        })
        .attr("data-group", function (d) {
            return d.group || d.name;
        })
        .on("mouseover", mouseover)



    d3.select("#container").on("mouseleave", mouseleave);


    // Add favicons
    var favicons = g.append("svg:image")
        .attr("display", function(d) {
            if (d.depth === 1 && d.children) {return}
            if (!d.domain) {return 'none'}
            // Don't show favicon for arcs that are smaller than n% of the whole thing
            if (d.size <= 2) {return 'none'}
        })
        .attr("xlink:href", function (d) {
            if (d.depth === 1 && d.children) { return "img/zab/shield-white-border-shadow.svg" }
            if (!d.domain || d.size <= 2) {return ''}
            return "https://favicon.yandex.net/favicon/" + d.domain
        })
        .attr("opacity", 0) // We add a `show` class if favicon was loaded successfully
        .attr("class", "favicon")
        .attr("width", 12)
        .attr("height", 12)
        .attr("y", -6)
        .attr("x", function(d) { return d.x-6-d.depth; }) // Fix icon positioning
        .attr("style", function(d) {
            if (d.depth === 1 && d.children) {
                return `width: 16px; height: 18px; x: -9; y: -9;`
            }
        })
        .attr("transform", function(d) {
            if (d.depth === 1 && d.children) {
                return "translate(" + arc.centroid(d) + ")"+
                       "rotate(" + getAngle(d) + ")";
            }
            if (d.depth > 0) {
                return "translate(" + arc.centroid(d) + ")"+
                       "rotate(" + getAngle(d) + ")";
            }  else {
                return null
            }
        })
        .attr("pointer-events", "none")


        // Attach load event handlers to our favicon image tags
        if (favicons && favicons.length > 0) {
            var handleFaviconLoad = function(e) {
                this.classList.add("show") // Increases opacity
                this.removeEventListener('load', handleFaviconLoad) // Cleanup
            }
            favicons[0].forEach(function(f) {
                if (!f || f.getAttribute('href') === "") { return } // Sanity checks
                f.addEventListener('load', handleFaviconLoad)
            })
        }


    function getAngle(d) {
        // Offset the angle by 90 deg since the '0' degree axis for arc is Y axis, while for text it is the X axis.
        var thetaDeg = (180 / Math.PI * (arc.startAngle()(d) + arc.endAngle()(d)) / 2 - 90);
        // If we are rotating the element by more than 90 deg, then "flip" it.
        return (thetaDeg > (90 + 10)) ? thetaDeg - 180 : thetaDeg; // Add 10deg to compensate the global -10deg tilt of the chart
    }


    // SVG Filters
    // https://github.com/wbzyl/d3-notes/blob/master/hello-drop-shadow.html
    // Read more about SVG filter effects here: http://www.w3.org/TR/SVG/filters.html

    // Filters go in defs element
    var defs = svg.append("defs");

    var gradient = defs.append("linearGradient")
        .attr("id", "gradient")
        .attr("x1", "0%")
        .attr("y1", "0%")
        .attr("x2", "100%")
        .attr("y2", "100%")
        .attr("spreadMethod", "pad");

    gradient.append("stop")
        .attr("offset", "0%")
        .attr("stop-color", "#1076B6")
        .attr("stop-opacity", 0.4);

    gradient.append("stop")
        .attr("offset", "100%")
        .attr("stop-color", "#1076B6")
        .attr("stop-opacity", 0.5);


    // create filter with id #drop-shadow
    // height=130% so that the shadow is not clipped
    var dropShadow = defs.append("filter")
        .attr("id", "drop-shadow")
        .attr("height", "130%");
    // SourceAlpha refers to opacity of graphic that this filter will be applied to
    // convolve that with a Gaussian with standard deviation 5 and store result
    // in blur
    dropShadow.append("feGaussianBlur")
        .attr("in", "SourceAlpha")
        .attr("stdDeviation", 5)
        .attr("result", "blur");
    // Translate output of Gaussian blur to the right and downwards with 0px
    // store result in offsetBlur
    dropShadow.append("feOffset")
        .attr("in", "blur")
        .attr("dx", 0)
        .attr("dy", 0)
        .attr("result", "offsetBlur");
    dropShadow.append("feFlood")
        .attr("in", "offsetBlur")
        .attr("flood-color", "#008ACE")
        .attr("flood-opacity", "0.5")
        .attr("result", "offsetColor");
    dropShadow.append("feComposite")
        .attr("in", "offsetColor")
        .attr("in2", "offsetBlur")
        .attr("operator", "in")
        .attr("result", "offsetBlur");
    // overlay original SourceGraphic over translated blurred opacity by using
    // feMerge filter. Order of specifying inputs is important!
    var feMerge = dropShadow.append("feMerge");
    feMerge.append("feMergeNode")
        .attr("in", "offsetBlur")
    feMerge.append("feMergeNode")
        .attr("in", "SourceGraphic")


    // Given a node in a partition layout, return an array of all of its ancestor
    // nodes, highest first, but excluding the root.
    function getAncestors(node) {
        var path = [];
        var current = node;
        while (current.parent) {
            path.unshift(current);
            current = current.parent;
        }
        return path;
    }


    // Restore everything to full opacity when moving off the visualization.
    function mouseleave(d) {
        renderCard("overview")
        // Transition each segment to full opacity and then reactivate it.
        d3.selectAll("path")
            .transition()
            .duration(100)
            .style("opacity", 1)
    }

    function mouseover(d) {
        var sequenceArray = getAncestors(d);
        // Fade all the segments.
        d3.selectAll("path")
            .style("opacity", 0.3);
        // Then highlight only those that are an ancestor of the current segment.
        svg.selectAll("path")
            .filter(function(node) {
                return (sequenceArray.indexOf(node) >= 0);
            })
            .style("opacity", 1);

        renderCard("hover", d)
    }

    document.getElementById("chart").classList.add("scale-in")

}



var mouseenterCardItem = function(e) {
    var groupName = $(this).data('group')
    if (!groupName) { return }
    // Fade all the segments.
    d3.selectAll("path")
        .transition()
        .duration(100)
        .style("opacity", 0.3)
    // Then highlight only those that are relevant to the group.
    d3.selectAll("svg [data-group=" + groupName + "]")
        .transition()
        .duration(100)
        .style("opacity", 1)
}


var mouseleaveCardItem = function(e) {
    // Reset
    d3.selectAll("path")
        .transition()
        .duration(100)
        .style("opacity", 1)
}



var renderCard = function(intent, d) {
    log.debug("renderCard", intent, d)
    var $card = $("#info-card-template").clone()
    var $target = $("#info-card")


    // Cleanup
    $target.removeAttr("data-group")
    $target.removeAttr("data-action")
    $target.removeAttr("data-purpose")


    if (intent === "hover") {
        var actionIconUnicode = (d.action === "block") ? "f05e" : "f05d"
        var actionIconHTML = `<i class="fa">&#x${actionIconUnicode};</i>`

        $target.find(".card-title").eq(0).html(`
            <span>${vAPI.i18n("zabGroupName_" + d.group) || d.group}</span>
            <span data-action="${d.action}">${actionIconHTML} ${vAPI.i18n("zabActionName_" + d.action) || d.action}</span>
        `)

        var purpose = (d.group === d.name) ? 'explanation' : 'detail'

        $target.attr("data-group", d.group || "")
        $target.attr("data-action", d.action || "")
        $target.attr("data-purpose", purpose)

        var cardBody = ""
        if (d.group === "content") {
            var contentScanned = "These requests have been checked, classified as regular content and therefore allowed."
            var contentPassed = "As ZenMate is disabled on this page all requests have been classified as content and allowed."


            var contentStr = (!popupData.netFilteringSwitch && popupData.hostStats.actions.block.r === 0) ? contentPassed : contentScanned

            cardBody = `
            <ul class="flex-item-block stats active">
                <li class="flex-item domain">
                    <div class="cat" style="background-image: url(https://favicon.yandex.net/favicon/${d.domain});">Domain</div>
                    <div class="pct marquee">${d.host}</div>
                </li>
                <li class="flex-item request">
                    <div class="cat">Requests</div>
                    <div class="pct">${d.allowCount || 0}</div>
                </li>

            </ul>
            <div class="info">${contentStr}</div>
            `

        }
        else if (d.depth === 1 && d.action === "block") {

            var groupExplanations = {
                ads: 'Next to slowing down your browsing, Advertising is often abused for tracking and in some cases to distribute Malware (so called "Malvertising").',
                privacy: 'Tracking is commonly used to to spy on your online behaviour and to uniquely identify you on the web.',
                security: 'Security Threats include malware and browser exploits, as well as phishing and spamming attacks.',
            }

            var explanationStr = groupExplanations[d.group] || ""

            var stats = popupData.hostStats.groups[d.group]
            cardBody = "explain blocking here: " + d.group
            cardBody = `
<div style="
  padding: 0 23px;
  color: #A9A9A9;
  height: 100%;
  margin-top: 7px;
  line-height: 14px;
  color: rgba(1,125,186,0.6);
    margin: 10px 0;
font-size: 12px;
  line-height: 17px;
  font-weight: 500;
  /* text-align: center; */
">ZenMate blocked ${stats.r} requests to ${stats.d} domains classified as ${vAPI.i18n("zabGroupName_" + d.group) || d.group}.</div>


<div style="
  padding: 0 23px;
color: #A9A9A9;
  height: 100%;
  margin-top: 7px;
  line-height: 14px;
    margin: 10px 0;
font-size: 12px;
  /* text-align: center; */
">${explanationStr}</div>

            `

        } else {
            //cardBody = "explain " + (d.blockCount || 0) + " blocked request here: " + d.host
            var filter = popupData.hostDict[d.host].filter
            cardBody = `
                ${d.blockCount || 0} requests blocked to ${d.host}<br>
                Filter: ${filter.t} / ${filter.info.title}
            `


    cardBody = `
            <ul class="flex-item-block stats active" style="margin-bottom: 0">
                <li class="flex-item" style="
  min-width: 0;
  flex-basis: 50%;
                ">
                    <div class="cat" style="
  background: url(https://favicon.yandex.net/favicon/${d.domain});
  background-repeat: no-repeat;
  background-position: center right;
  background-size: 12px 12px;
                    ">Domain</div>
                    <div class="pct marquee" style="    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
font-size: 16px;
margin:0;
    ">${d.host}</div>



                </li>
                <li class="flex-item">
                    <div class="cat">Type</div>
                    <div class="pct" style="font-size: 16px">${d.filter.t || "None"}</div>
                </li>

            </ul>


<div style="
  padding: 0 23px;
  color: #A9A9A9;
  height: 100%;
  margin-top: 7px;
  line-height: 14px;
  color: rgba(1,125,186,0.6);
  /* text-align: center; */
">${d.blockCount} requests have been classified as ${vAPI.i18n("zabGroupName_" + d.group) || d.group} (Filter: ${d.filter.info.title || "None"}) and blocked. </div>

            `
        }

        $target.find(".card-body").html(cardBody)

        $.each($target.find('.marquee'), function(e) {
            if (e.scrollHeight > e.clientHeight || e.scrollWidth > e.clientWidth) {
                // Element is overflowing, let's go oldschool with a <marquee> tag :-)
                $(e).html('<marquee behavior="alternate" scrollamount="5" scrolldelay="300">&nbsp;' + $(e).html() + '&nbsp;&nbsp;</marquee>')
            }
        })

    }

    if (intent === "shield") {
        var activeBlacklists = _.filter(popupData.blacklists, function(o) { return o.off === false })
        var entryCount = _.reduce(activeBlacklists, function(s, entry) {
            return s + entry.entryUsedCount;
        }, 0)

        var statStr = `ZenMate blocked ${formatNumber(popupData.pageBlockedRequestCount)} of ${formatNumber(popupData.pageAllowedRequestCount)} requests on this page.`
        if (popupData.globalBlockedRequestCount && popupData.globalBlockedRequestCount > 0) {
            statStr += ` Since installation ${formatNumber(popupData.globalBlockedRequestCount)} requests have been blocked, which saved you ${Math.round(popupData.globalBlockedRequestCount * 100 / popupData.globalAllowedRequestCount)}% in total.`
        }

        var cardBody = `
<div style="
  padding: 0 23px;
  color: #A9A9A9;
  height: 100%;
  margin-top: 7px;
  line-height: 14px;
  color: rgba(1,125,186,0.6);
    margin: 10px 0;
font-size: 12px;
  line-height: 17px;
  font-weight: 500;
  /* text-align: center; */
">
${statStr}
</div>


<div style="
  padding: 0 23px;
color: #A9A9A9;
  height: 100%;
  margin-top: 7px;
  line-height: 14px;
    margin: 10px 0;
font-size: 12px;
  /* text-align: center; */
">Currently able to block ${formatNumber(entryCount)} elements (${Object.keys(activeBlacklists).length} lists).</div>


        `
        $target.attr("data-group", "shield")

        $target.find(".card-title").eq(0).html(`
            <span>ZenMate Web Firewall</span>
            <span class="mute">v${popupData.appVersion}</span>
        `)

        //$target.html($card.html())
        $target.find(".card-body").html(cardBody)

        $target.addClass("scale-in")


    }

    if (intent === "overview") {
        if (!popupData || !popupData.hostStats || popupData.hostStats.actions.all.d === 0) {
            $target.removeClass("scale-in")
            return
        } // FIXME: Handle this condition better

        var blockStats = "{{percent}}% blocked"
            .replace('{{percent}}', popupData.hostStats.actions.block.pct)

        var domainStats = "{{blockCount}} of {{totalCount}} domains"
            .replace('{{blockCount}}', popupData.hostStats.actions.block.d)
            .replace('{{totalCount}}', popupData.hostStats.actions.all.d)

        $target.find(".card-title").eq(0).html(`
            <span><i class="fa">&#xf05e;</i> ${blockStats}</span>
            <span class="mute">${domainStats}</span>
        `)


        // Active tems
        var activeItems = []
        // Inactive items
        var inactiveItems = _.clone(availableBlockGroups)
        // availableBlockGroups

        _.forEach(popupData.hostStats.groups, function(n, key) {
            var item = Object.assign({}, n)
            item.name = key
            activeItems.push(item)

            // Remove group from inactiveItems array
            if (inactiveItems.indexOf(key) > -1) {
                inactiveItems.splice(inactiveItems.indexOf(key), 1)
            }
        })
        // Sort array by percentage, descending
        _.sortBy(activeItems, 'pct').reverse()

        // Only add content if we have nothing else to show
        if (activeItems.length === 0) {
            var item = Object.assign({}, popupData.hostStats.actions.allow)
            item.name = "content"
            activeItems.push(item)
        }

        var listItems = ""
        _.forEach(activeItems, function(n) {
            //console.debug(n)
            listItems += `
                <li class="flex-item" data-group="${n.name}">
                    <div class="cat">${vAPI.i18n("zabGroupName_" + n.name) || n.name}</div>
                    <div class="pct">${Math.round(n.pct)}%</div>
                    <div class="progress" style="background: #ECECEC; height: 5px">
                        <div style="height: 5px; width: ${Math.round(n.pct)}%"></div>
                    </div>
                </li>
            `
        })

        // Add list items
        $card.find(".stats.active").html(listItems)



        var inactiveListItems = ""
        if (inactiveItems.length > 0) {
            var zabGroupsNotFoundOverview = "No {{groupList}} detected."
            var prettyGroupNameList = inactiveItems.map(function(e) { return vAPI.i18n("zabGroupName_" + e) || e}).join(', ')
            inactiveListItems = `
                <li class="flex-item">
                    <div style="font-weight: 500;font-size: 11px;"><i class="fa">&#xf00c;</i> ${zabGroupsNotFoundOverview.replace("{{groupList}}", prettyGroupNameList)}</div>
                </li>
            `
        }

        // Overwrite text in case ZenMate has been disabled
        if (!popupData.netFilteringSwitch) {
            inactiveListItems = `
                <li class="flex-item">
                    <div>ZenMate has been disabled on this page.</div>
                </li>
            `
        }

        // Add inactive groups
        $card.find(".inactive-items").html(inactiveListItems)
        $target.attr("data-group", "overview")

        //$target.html($card.html())
        $target.find(".card-body").html($card.find(".card-body").html())

        $target.addClass("scale-in")

        $target.find(".stats.active li").on("mouseenter", mouseenterCardItem)
        $target.find(".stats.active li").on("mouseleave", mouseleaveCardItem)

    }

}


var renderPopupEx = function() {
    // Create clean hostDict based on hostnameDict
    var hostDict = {}
    _.forEach(popupData.hostnameDict, function(n, key) {
        // popupData.hostnameDict contains empty entries for parent FQDNs we're not interested in
        if (n.allowCount === 0 && n.blockCount === 0) { return }
        hostDict[key] = n
    })

    // Add data from enriched netFilterLog to hostDict
    _.forEach(popupData.netFilterLog, function(n, key) {
        // Skip entry if it's a not blocked but force allow entry
        // TODO: Add support for whitelist allow entries in UI
        if (!n.b) {
            log.debug("zab > Not block action:", n, key)
            return
        }
        // Skip entry if enriched info object is missing
        if (!n.info) {
            log.debug("zab > No info object:", n, key)
            return
        }
        // Skip if host of the netFilterLog entry is not present in hostDict
        if (!hostDict[n.rh]) {
            log.debug("zab > Host not found in hostDict", n, key, hostDict)
            return
        }
        if (n.info.path && popupData.blacklists[n.info.path]) {
            // Fetch the custom group name from blacklist object
            n.group = popupData.blacklists[n.info.path].zab_group
        } else {
            log.warn("zab > group missing", n.info.path)
        }

        // Add filter information to entry in hostDict
        hostDict[n.rh].filter = n
    })

    // Add stats about request and domain block counts per action or group
    var hostStats = {
        actions: {
            all: {r:0, d: 0},
            allow: {r:0, d: 0},
            block: {r:0, d: 0}
        },
        groups: {}
    }
    _.forEach(hostDict, function(n, key) {
        hostStats.actions.all.d += 1
        hostStats.actions.all.r += n.allowCount
        hostStats.actions.all.r += n.blockCount

        if (n.allowCount > 0) {
            hostStats.actions.allow.d += 1
            hostStats.actions.allow.r += n.allowCount
        }
        if (n.blockCount > 0) {
            hostStats.actions.block.d += 1
            hostStats.actions.block.r += n.blockCount
        }

        if (n.filter && n.filter.group) {
            if (!hostStats.groups[n.filter.group]) {hostStats.groups[n.filter.group] = {r: 0, d: 0}}
            hostStats.groups[n.filter.group].d += 1
            hostStats.groups[n.filter.group].r += n.blockCount || n.allowCount
        }

        // Add host to object
        n.host = key
    })
    // Calculate and add percentages based on hosts total vs. hosts blocked
    // We do this in a simplified manner, focussing on the blocked hosts
    // Allowed hosts are only considered as such if they're 100% clean

    // Sanity check in case of single host requests
    if (hostStats.actions.block.d >= hostStats.actions.all.d) {
        hostStats.actions.all.d = hostStats.actions.block.d + hostStats.actions.allow.d
    }

    hostStats.actions.block.pct = Math.round(hostStats.actions.block.d * 100 / hostStats.actions.all.d)
    hostStats.actions.allow.pct = 100 - hostStats.actions.block.pct


    // Calculate percentages for each (block) filter group based on host
    _.forEach(hostStats.groups, function(n, key) {
        var pctBlocked = hostStats.actions.block.pct
        n.pct = hostStats.actions.block.pct * n.d / hostStats.actions.block.d
    })


    // Generate chart data
    var chartData = {
        name: "sunburst",
        children: []
    }
    // Add filter groups
    var hostDict1 = _.cloneDeep(hostDict)
    _.forEach(hostStats.groups, function(g, groupKey) {
        // Fetch all items for that specific filter group from hostDict
        var children = _.filter(hostDict1, function(o) { return o.filter && o.filter.group === groupKey })
        // Iterate over each item and calculate relative percentage (based on requests)
        _.forEach(children, function(c, childKey) {
            c.size = g.pct * c.blockCount / g.r
            c.name = c.host
            c.action = "block"
            c.group = groupKey
        })
        chartData.children.push({
            name: groupKey,
            action: "block",
            group: groupKey,
            children: children,
            r: g.r, d: g.d, pct: g.pct
        })

    })

    // Add allowed hosts
    var hostDict2 = _.cloneDeep(hostDict)
    var children = _.filter(hostDict2, function(o) { return o.allowCount > 0 })
    _.forEach(children, function(c, childKey) {
        // Calculate relative size
        c.size = hostStats.actions.allow.pct * c.allowCount / hostStats.actions.allow.r
        c.name = c.host
        c.action = "allow"
        c.group = "content"
        chartData.children.push(c)
    })


    // Assign calculated data to popupData so we can re-use it later on
    popupData.hostDict = hostDict
    popupData.hostStats = hostStats


    // Don't render the chart when we're still waiting for enriched netFilterLogs
    // KISS style checking the first entry only :-)
    if (popupData && popupData.netFilterLog) {
        var filterLogs = Object.keys(popupData.netFilterLog)
        if (filterLogs.length === 0) {
            renderChart(chartData)
            renderCard("overview")
        } else if (popupData.netFilterLog[filterLogs[0]].info) {
            renderChart(chartData)
            renderCard("overview")
        }
    }
}



var renderToggleStatus = function(enabled) {
    if (enabled) {
        $("#mainswitch").attr("checked", "checked")
        $("#status").html(`
            Enabled on <div class="domain"><div class="truncated">${popupData.pageHostname}</div></div>
        `).attr("title", "Enabled on " + popupData.pageHostname)
        $(".radar").addClass("active")

    } else {
        $("#mainswitch").removeAttr("checked")
        $("#status").html(`
            Disabled on <div class="domain"><div class="truncated">${popupData.pageHostname}</div></div>
        `).attr("title", "Disabled on " + popupData.pageHostname)
        $(".radar").removeClass("active")
    }
}


var renderPopup = function() {
    if (popupData.netFilteringSwitch) {
        renderToggleStatus(true)
    } else {
        renderToggleStatus(false)
    }

    // Handle internal pages, remove toggle
    // TODO: Make cross browser
    if (popupData.pageHostname === 'behind-the-scene' || (popupData.rawURL.indexOf("chrome-extension://") === 0) || (popupData.rawURL.indexOf("chrome://") === 0)) {
        renderToggleStatus(true)
        $("#status").html(`
            <i class="fa"></i> Firewall enabled
        `)
        $(".switch-block").addClass("hide")
    } else {
        $(".switch-block").removeClass("hide")
    }

    $(".switch-block").addClass("scale-in")
    $("#status").addClass("scale-in")


    // Make sure we have advanced data to show before trying to render it
    if (Object.keys(popupData.hostnameDict).length > 0) {
        renderPopupEx()
    }

    // Handle special state after installation when we haven't blocked anything yet
    if (Object.keys(popupData.hostnameDict).length === 0 && popupData.pageAllowedRequestCount === 0 && popupData.pageBlockedRequestCount === 0 && popupData.netFilteringSwitch) {
        uDom('body').toggleClass('dirty', true);
    }

};

/******************************************************************************/

var renderPopupLazy = function() {
    var onDataReady = function(data) {
        //console.debug('renderPopupLazy - onDataReady', data)
        if ( !data ) { return; }
        var v = data.hiddenElementCount || '';
    };

    messager.send({
        what: 'getPopupDataLazy',
        tabId: popupData.tabId
    }, onDataReady);
};

/******************************************************************************/

var toggleNetFilteringSwitch = function(e) {
    if ( !popupData || !popupData.pageURL ) {
        return;
    }
    messager.send({
        what: 'toggleNetFiltering',
        url: popupData.pageURL,
        scope: '',
        state: e.target.checked,
        tabId: popupData.tabId
    });

    renderToggleStatus(e.target.checked)

    hashFromPopupData();
};

/******************************************************************************/

var gotoPick = function() {
    messager.send({
        what: 'launchElementPicker',
        tabId: popupData.tabId
    });

    vAPI.closePopup();
};

/******************************************************************************/

var gotoURL = function(ev) {
    if ( this.hasAttribute('href') === false) {
        return;
    }

    ev.preventDefault();

    var rel = this.getAttribute('rel') || '';

    messager.send({
        what: 'gotoURL',
        details: {
            url: this.getAttribute('href'),
            select: true,
            index: -1,
            popup: rel === 'popup' && ev.shiftKey
        }
    });

    vAPI.closePopup();
};

/******************************************************************************/

var reloadTab = function() {
    messager.send({ what: 'reloadTab', tabId: popupData.tabId, select: true });

    // Polling will take care of refreshing the popup content
    // https://github.com/chrisaljoudi/uBlock/issues/748
    // User forces a reload, assume the popup has to be updated regardless if
    // there were changes or not.
    popupData.contentLastModified = -1;

    // No need to wait to remove this.
    uDom('body').toggleClass('dirty', false);
};

/******************************************************************************/

// Poll for changes.
//
// I couldn't find a better way to be notified of changes which can affect
// popup content, as the messaging API doesn't support firing events accurately
// from the main extension process to a specific auxiliary extension process:
//
// - broadcasting() is not an option given there could be a lot of tabs opened,
//   and maybe even many frames within these tabs, i.e. unacceptable overhead
//   regardless of whether the popup is opened or not.
//
// - Modifying the messaging API is not an option, as this would require
//   revisiting all platform-specific code to support targeted broadcasting,
//   which who knows could be not so trivial for some platforms.
//
// A well done polling is a better anyways IMO, I prefer that data is pulled
// on demand rather than forcing the main process to assume a client may need
// it and thus having to push it all the time unconditionally.

var pollForContentChange = (function() {
    var pollTimer = null;

    var pollCallback = function() {
        pollTimer = null;
        messager.send(
            {
                what: 'hasPopupContentChanged',
                tabId: popupData.tabId,
                contentLastModified: popupData.contentLastModified
            },
            queryCallback
        );
    };

    var queryCallback = function(response) {
        if ( response ) {
            getPopupData(popupData.tabId);
            return;
        }
        poll();
    };

    var poll = function() {
        if ( pollTimer !== null ) {
            return;
        }
        pollTimer = vAPI.setTimeout(pollCallback, 1500);
    };

    return poll;
})();

/******************************************************************************/

var getPopupData = function(tabId) {
    var onDataReceived = function(response) {
        if (response && response.debug_log) {
            log.enableAll()
            log.debug('Debug logging enabled.')
        }
        log.info('getPopupData - onDataReceived', response)
        cachePopupData(response);
        renderPopup();
        renderPopupLazy(); // low priority rendering
        hashFromPopupData(true);
        pollForContentChange();
    };
    messager.send({ what: 'getPopupData', tabId: tabId }, onDataReceived);
    getEnrichedNetFilterLog(tabId) // TODO: Check if necessary or if all data is already available
};

/******************************************************************************/

var getEnrichedNetFilterLog = function(tabId) {
    var onDataReceived = function(data) {
        log.debug("getEnrichedNetFilterLog - onDataReceived", data)
        popupData.netFilterLog = data;
        renderPopup();
    };
    zabMessager.send({ what: 'getEnrichedNetFilterLog', tabId: tabId }, onDataReceived);
};

/******************************************************************************/

$(document).ready(function() {

    $("#center .radar").addClass("active")

    // If there's no tab id specified in the query string,
    // it will default to current tab.
    var tabId = null;
    // Extract the tab id of the page this popup is for
    var matches = window.location.search.match(/[\?&]tabId=([^&]+)/);
    if ( matches && matches.length === 2 ) {
        tabId = matches[1];
    }
    getPopupData(tabId);

    // Set up event listeners
    $("#mainswitch").on("change", toggleNetFilteringSwitch)
    $("#refresh").on("click", reloadTab)
    $(".radar .shield").on("mouseenter", function(e) { $("svg").addClass("mute"); renderCard("shield") })
    $(".radar .shield").on("mouseleave", function(e) { $("svg").removeClass("mute"); renderCard("overview") })
})


/******************************************************************************/

})();
