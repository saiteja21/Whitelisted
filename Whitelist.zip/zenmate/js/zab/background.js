/*******************************************************************************

    Copyright (C) 2016 ZenMate

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

*/

/* global vAPI, µBlock */

/******************************************************************************/

(function() {

'use strict';

/******************************************************************************/


// Add ZAB specific settings
µBlock.zabSettings = {
}

// List enabled ZAB groups
µBlock.zabGroups = [
    "privacy", "ads", "security"
]

// Support for debug logging
log.disableAll() // Init
vAPI.storage.get('debug_log', function(data) {
    if (data && data.debug_log) {
        log.enableAll()
        log.debug("Debug logging enabled.")
    }
})


vAPI.storage.get('installed_at', function(data) {
    if (!data || !data.installed_at) {
        µBlock.installed_at = Math.floor((new Date()).getTime()) // UTC
        vAPI.storage.set({
            "installed_at": µBlock.installed_at
        })
        fetch("https://api.zenguard.biz/v2/et/zab/install?t=" + µBlock.installed_at)
    } else {
        µBlock.installed_at = data.installed_at
        fetch("https://api.zenguard.biz/v2/et/zab/init?t=" + µBlock.installed_at)
    }

    var after = 24 * 60 * 60 * 1000 // 1d
    var onTimeout = function() {
        fetch("https://api.zenguard.biz/v2/et/zab/daily?t=" + µBlock.installed_at)
        vAPI.setTimeout(onTimeout, after)
    }
    vAPI.setTimeout(onTimeout, after)
})



})();