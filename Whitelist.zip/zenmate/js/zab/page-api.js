function injectFn(version) {
  window.__zab = {
    getData(cb) {
      var data = {
        version: version
      };

      if (cb) { // to be consistent with vpn extension
        return cb(data);
      }

      return data;
    }
  };
}

// Add script tag documentElement node
function addScriptTag(node, script, id) {
  if (document.getElementById(id)) {
    return;
  }

  var s = document.createElement('script');

  s.setAttribute('type', 'text/javascript');
  s.setAttribute('charset', 'utf-8');

  s.id = id;
  s.innerHTML = script;

  node.appendChild(s);
}


addScriptTag(document.documentElement, `(${injectFn})('${chrome.runtime.getManifest().version}');`, 'zab-page-api');
