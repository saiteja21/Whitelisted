/*******************************************************************************

    Copyright (C) 2016 ZenMate

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

*/

/* global vAPI, µBlock */

/******************************************************************************/

(function() {

'use strict';

/******************************************************************************/

/*

uBlock Original Groups (3p-filters.js)

    var groupKeys = [
        'default',
        'ads',
        'privacy',
        'malware',
        'social',
        'multipurpose',
        'regions',
        'custom'
    ];

*/

var enrichListsWithZABdata = function(lists) {
    // TODO: Add ZAB specific lists

    for ( var path in lists ) {
        if ( lists.hasOwnProperty(path) === false ) {
            continue;
        }
        lists[path].zab_group = lists[path].group // Init

        // Map uBlock groups to ZAB groups
        if (lists[path].group === "regions") { lists[path].zab_group = "ads" }
        if (lists[path].group === "malware") { lists[path].zab_group = "security" }
        if (lists[path].group === "multipurpose") { lists[path].zab_group = "privacy" } // Not optimal
        if (lists[path].group === "social") { lists[path].zab_group = "privacy" } // TODO: Add support for social group

        // Assign proper group for internal uBlock lists
        if (path === "assets/ublock/filters.txt") { lists[path].zab_group = "ads" }
        if (path === "assets/ublock/privacy.txt") { lists[path].zab_group = "privacy" }
        if (path === "assets/ublock/badware.txt") { lists[path].zab_group = "security" }
        if (path === "assets/ublock/experimental.txt") { lists[path].zab_group = "privacy" }
        if (path === "assets/ublock/unbreak.txt") { lists[path].zab_group = "privacy" }

        // To suppress warnings, we'll add proper group support for user defined list in the future.
        if (path === "assets/user/filters.txt") { lists[path].zab_group = "privacy" }

        if (µBlock.zabGroups.indexOf(lists[path].zab_group) < 0) {
            console.warn("zab > enrichListsWithZABdata - unknown group:", lists[path].group, lists[path].zab_group, path)
            // Worst case fallback, we should never ship unknown blacklists in the first place
            lists[path].zab_group = "privacy"
        }

        // Enable some more lists by default
        if (µBlock.firstInstall) {
            var listsToEnable = [
                "https://easylist-downloads.adblockplus.org/antiadblockfilters.txt",
                "https://www.fanboy.co.nz/enhancedstats.txt",
            ]
            if (listsToEnable.indexOf(path) > -1) {
                lists[path].off = false
            }
        }

        //console.debug("enrichListsWithZABdata", path, lists[path])

    }

    return lists
}

// TODO: Overwrite autoSelectFilterLists (utilize `µb.firstInstall`)

// Overwrite getAvailableLists so we can add ZAB specific meta data
µBlock.getAvailableLists_orig = µBlock.getAvailableLists
µBlock.getAvailableLists = function(callback) {
    µBlock.getAvailableLists_orig(function(lists){
        //console.debug("zab - µBlock.getAvailableLists", lists)
        callback(enrichListsWithZABdata(lists))
    })
}


})();