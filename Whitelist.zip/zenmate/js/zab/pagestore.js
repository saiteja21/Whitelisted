/*******************************************************************************

    Copyright (C) 2016 ZenMate

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

*/

/* global vAPI, µBlock */

/******************************************************************************/

(function() {

'use strict';

/******************************************************************************/

var µb = µBlock;

// Overwrite init to add netFilterLog object to PageStore
µb.PageStore.PageStore.prototype.init_orig = µb.PageStore.PageStore.prototype.init
µb.PageStore.PageStore.prototype.init = function(tabId) {
    this.netFilterLog = {}
    this.init_orig(tabId)
}


// Make sure to release memory
µb.PageStore.PageStore.prototype.dispose_orig = µb.PageStore.PageStore.prototype.dispose
µb.PageStore.PageStore.prototype.dispose = function() {
    this.netFilterLog = {}
    this.dispose_orig()
}


// Overwrite logRequest to add more detailed netFilter logging
µb.PageStore.PageStore.prototype.logRequest_orig = µb.PageStore.PageStore.prototype.logRequest
µb.PageStore.PageStore.prototype.logRequest = function(context, result) {
    if (result && result.length > 1 && result.charAt(0) === 's') {
        // console.debug('ZAB: PageStore.prototype.logRequest', {context: context, result: result, netFilterLog: this.netFilterLog})
        if (!this.netFilterLog[context.requestURL]) {
            // Add to netFilterLog with requestURL as key (unless present)
            this.netFilterLog[context.requestURL] = {
                f: result, // compiled filter with prefix, e.g. "sb:0.google-analytics.com"
                t: context.requestType, // e.g. "script"
                u: context.requestURL, // e.g. "https://www.google-analytics.com/analytics.js"
                h: context.pageHostname, // e.g. "render.githubusercontent.com"
                b: (result.charAt(1) === 'b') // blocked = true, allowed = false
            }
        }
    }
    // Pass on to original logRequest handler
    this.logRequest_orig(context, result)
}

})();