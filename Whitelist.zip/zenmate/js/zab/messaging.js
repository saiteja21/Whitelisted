/*******************************************************************************

    Copyright (C) 2016 ZenMate

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

*/

/* global vAPI, µBlock */

/******************************************************************************/

(function() {

'use strict';

/******************************************************************************/

var µb = µBlock;

/******************************************************************************/


var getEnrichedNetFilterLogFromRequest = function(request, callback) {
    //console.debug("getEnrichedNetFilterLogFromRequest", request)
    if ( request.tabId ) {
        getEnrichedNetFilterLogFromTabId(request.tabId, callback)
        return;
    }

    // Use currently selected tab if no target tabId is found.
    vAPI.tabs.get(null, function(tab) {
        var tabId = null;
        if (tab) {
            tabId = tab.id;
        }
        //console.debug("tabs.get tabId", tabId)
        getEnrichedNetFilterLogFromTabId(tabId, callback)
    });
};


var getEnrichedNetFilterLogFromTabId = function(tabId, callback) {
    if (!tabId) {
        //console.debug("zab.messaging - getEnrichedNetFilterLog: tabId missing")
        return callback({})
    }
    var pageStore = µb.pageStoreFromTabId(tabId)
    if (!pageStore) {
        //console.debug("zab.messaging - getEnrichedNetFilterLog: no pageStore", pageStore)
        return callback({})
    }
    var netFilterLog = pageStore.netFilterLog
    if (!netFilterLog || Object.keys(netFilterLog).length === 0) {
        //console.debug("zab.messaging - getEnrichedNetFilterLog: no/empty pageStore.netFilterLog", pageStore)
        return callback({})
    }

    // Check netFilterLog items for existing info objects and create array with filter strings to check
    // Return false if the object already exists (is being filtered out later) or the filter string
    // TODO: deduplicate to save lookup worker resources
    var filtersToCheck = _.map(netFilterLog, function(item) { return (item.info ? false : item.f); }).filter(Boolean)

    //console.debug("zab.messaging - getEnrichedNetFilterLog - filtersToCheck", filtersToCheck, JSON.stringify(netFilterLog, null, 2))

    // Check if there's actually something to do or if we already have all netFilterLog details cached
    if (filtersToCheck.length === 0) {
        return callback(netFilterLog)
    }

    // Poor mans async control flow
    var remainingFilterCount = filtersToCheck.length;
    var checkFilterCount = function() {
        remainingFilterCount -= 1;
        if (remainingFilterCount <= 0) {
            // We're done here
            return callback(compileEnrichedNetFilterLog())
        }
    }

    var filterDetail = {}
    var handleLookupData = function(data) {
        if (!data) { // Should never happen
            console.error("zab > staticFilteringReverseLookup: unexpected result", data);
            return checkFilterCount()
        }
        var key = Object.keys(data)[0] // We expect an object with a single key
        if (!key || !data[key]) { // Should never happen
            console.error("zab > staticFilteringReverseLookup: unexpected result", data);
            return checkFilterCount()
        }
        if (data[key].length === 0) {
            // It should never happen that the filter lookup yields no result but just in case
            console.warn("zab > staticFilteringReverseLookup: empty lookup results", data);
            filterDetail[key] = {}
            return checkFilterCount()
        }

        // Multiple lists can contain a filter, let's only take the 1st one
        filterDetail[key] = data[key][0]
        return checkFilterCount()
    }

    // Add filterDetail info to netFilterLog
    var compileEnrichedNetFilterLog = function() {
        ////console.debug("netFilterLog", JSON.stringify(netFilterLog, null, 2))
        _.forEach(netFilterLog, function(nf, key){
            if (!filterDetail[nf.f]) {
                console.warn("zab > compileEnrichedNetFilterLog: no matching filter detail found", nf, netFilterLog, filterDetail)
                return
            }
            // Add detailed filter information from lookup to info property
            nf.info = filterDetail[nf.f]
            // Add request host and domain
            nf.rh = µb.URI.hostnameFromURI(nf.u)
            nf.rd = µb.URI.domainFromHostname(nf.rh)
        })
        return netFilterLog
    }

    // Kickstart the filter detail lookups for each filter
    _.forEach(filtersToCheck, function(f){
        var filter = (f[2] === ':') ? f.slice(3) : f;
        µb.staticFilteringReverseLookup.fromNetFilter(
            filter, f, handleLookupData
        );
    })

}


var onMessage = function(request, sender, callback) {
    // Async
    switch ( request.what ) {

        case 'getEnrichedNetFilterLog':
            getEnrichedNetFilterLogFromRequest(request, callback);
            return;

        default:
            break;
    }

    // Sync
    var response;
    switch ( request.what ) {

        default:
            return vAPI.messaging.UNHANDLED;
    }

    callback(response);
};

vAPI.messaging.listen('zab', onMessage);

/******************************************************************************/

})();